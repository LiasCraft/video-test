---
f_vimeo-video-id: '999230537'
f_video-thumbnail: >-
  https://player.vimeo.com/progressive_redirect/playback/999230537/rendition/720p/file.mp4?loc=external&log_user=0&signature=52a0d95412ae12f3bfdacace2d2ebab3f6ba47d5a2bcd8100be9c9baee49d6f6
title: Video 3
slug: video-3
updated-on: '2024-09-26T21:22:21.896Z'
created-on: '2024-09-26T21:22:21.896Z'
published-on: '2024-10-15T20:34:27.520Z'
layout: '[videos].html'
tags: videos
---


