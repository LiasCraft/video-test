---
f_vimeo-video-id: '999230779'
title: Video
slug: video
updated-on: '2024-09-26T21:21:38.376Z'
created-on: '2023-02-23T18:34:03.086Z'
published-on: '2024-10-15T20:34:27.520Z'
f_video-thumbnail: >-
  https://player.vimeo.com/progressive_redirect/playback/999230779/rendition/720p/file.mp4?loc=external&log_user=0&signature=0f6868b90552b6e308b6d7ea8cee436b104fc53543424221947e7528f64644c7
layout: '[videos].html'
tags: videos
---


